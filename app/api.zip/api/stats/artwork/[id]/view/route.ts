import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

type Props = {
  params: Promise<{
    id: string;
  }>;
};

export async function POST(
  request: Request,
  { params }: Props
) {
  try {
    const { id } = await params;

    const artworkId = Number(id);

    if (!Number.isInteger(artworkId)) {
      return NextResponse.json(
        {
          error: "Некорректный ID картины",
        },
        {
          status: 400,
        }
      );
    }

    const artwork = await prisma.artwork.findUnique({
      where: {
        id: artworkId,
      },
    });

    if (!artwork) {
      return NextResponse.json(
        {
          error: "Картина не найдена",
        },
        {
          status: 404,
        }
      );
    }

    const stats = await prisma.artworkStats.upsert({
      where: {
        artworkId,
      },
      update: {
        views: {
          increment: 1,
        },
      },
      create: {
        artworkId,
        views: 1,
        clicks: 0,
      },
    });

    return NextResponse.json({
      success: true,
      stats,
    });
  } catch (error) {
    console.error(
      "Artwork view statistics error:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        error: "Не удалось сохранить просмотр",
      },
      {
        status: 500,
      }
    );
  }
}