import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST() {
  try {
    const now = new Date();

    const startOfDay = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate()
    );

    const endOfDay = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() + 1
    );

    const stats = await prisma.siteStats.upsert({
      where: {
        date: startOfDay,
      },
      update: {
        visits: {
          increment: 1,
        },
      },
      create: {
        date: startOfDay,
        visits: 1,
        uniqueVisits: 0,
      },
    });

    return NextResponse.json({
      success: true,
      stats,
    });
  } catch (error) {
    console.error("Visit statistics error:", error);

    return NextResponse.json(
      {
        success: false,
        error: "Не удалось сохранить посещение",
      },
      {
        status: 500,
      }
    );
  }
}