import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

function createSlug(title: string) {
  return title
    .toLowerCase()
    .trim()
    .replace(/ё/g, "е")
    .replace(/[^a-zа-я0-9\s-]/gi, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

async function getUniqueSlug(title: string) {
  const baseSlug = createSlug(title);

  let slug = baseSlug;
  let counter = 1;

  while (true) {
    const existing = await prisma.artwork.findUnique({
      where: {
        slug,
      },
    });

    if (!existing) {
      return slug;
    }

    slug = `${baseSlug}-${counter}`;
    counter++;
  }
}

export async function GET() {
  try {
    const artworks = await prisma.artwork.findMany({
      orderBy: {
        createdAt: "desc",
      },
    });

    return NextResponse.json(artworks);
  } catch (error) {
    console.error(
      "GET /api/artworks:",
      error
    );

    return NextResponse.json(
      {
        error: "Ошибка загрузки картин",
      },
      {
        status: 500,
      }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    if (!body.title?.trim()) {
      return NextResponse.json(
        {
          error: "Название картины обязательно",
        },
        {
          status: 400,
        }
      );
    }

    if (!body.image) {
      return NextResponse.json(
        {
          error: "Изображение обязательно",
        },
        {
          status: 400,
        }
      );
    }

    const slug = await getUniqueSlug(
      body.title
    );

    const artwork = await prisma.artwork.create({
      data: {
        title: body.title.trim(),

        slug,

        image: body.image,

        year: Number(body.year),

        price: Number(body.price),

        width: Number(body.width),

        height: Number(body.height),

        material:
          body.material?.trim() || "",

        size:
          body.size?.trim() ||
          `${body.width} × ${body.height} см`,

        description:
          body.description?.trim() || "",

        category: "Живопись",

        status:
          body.status || "available",
      },
    });

    return NextResponse.json(
      artwork,
      {
        status: 201,
      }
    );
  } catch (error) {
    console.error(
      "POST /api/artworks:",
      error
    );

    return NextResponse.json(
      {
        error: "Ошибка создания картины",
      },
      {
        status: 500,
      }
    );
  }
}