import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function DELETE(
  request: NextRequest
) {
  try {
    const body = await request.json();

    const ids: number[] = body.ids;

    if (!ids.length) {
      return NextResponse.json(
        {
          error: "Нет выбранных картин",
        },
        {
          status: 400,
        }
      );
    }

    await prisma.artwork.deleteMany({
      where: {
        id: {
          in: ids,
        },
      },
    });

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Ошибка удаления",
      },
      {
        status: 500,
      }
    );
  }
}