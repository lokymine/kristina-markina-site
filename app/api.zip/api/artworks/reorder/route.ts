import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function PATCH(
  request: NextRequest
) {
  try {
    const body = await request.json();

    const artworks: {
      id: number;
      order: number;
    }[] = body.artworks;

    await prisma.$transaction(
      artworks.map((artwork) =>
        prisma.artwork.update({
          where: {
            id: artwork.id,
          },
          data: {
            order: artwork.order,
          },
        })
      )
    );

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Не удалось сохранить порядок",
      },
      {
        status: 500,
      }
    );
  }
}