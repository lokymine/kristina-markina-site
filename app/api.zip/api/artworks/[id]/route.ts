import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

type Context = {
  params: Promise<{
    id: string;
  }>;
};

export async function GET(
  request: Request,
  { params }: Context
) {
  try {
    const { id } = await params;

    const artwork = await prisma.artwork.findFirst({
      where: {
        OR: [
          {
            slug: id,
          },
          {
            id: Number(id) || -1,
          },
        ],
      },
    });

    if (!artwork) {
      return NextResponse.json(
        {
          error: "Картина не найдена",
        },
        {
          status: 404,
        }
      );
    }

    return NextResponse.json(artwork);
  } catch (error) {
    console.error(
      "GET /api/artworks/[id]:",
      error
    );

    return NextResponse.json(
      {
        error: "Ошибка получения картины",
      },
      {
        status: 500,
      }
    );
  }
}

export async function PATCH(
  request: Request,
  { params }: Context
) {
  try {
    const { id } = await params;

    const numericId = Number(id);

    if (!Number.isInteger(numericId)) {
      return NextResponse.json(
        {
          error: "Некорректный ID картины",
        },
        {
          status: 400,
        }
      );
    }

    const body = await request.json();

    const artwork = await prisma.artwork.update({
      where: {
        id: numericId,
      },
      data: {
        title: body.title?.trim(),

        image: body.image,

        year: Number(body.year),

        price: Number(body.price),

        width: Number(body.width),

        height: Number(body.height),

        material:
          body.material?.trim() || "",

        size:
          body.size?.trim() ||
          `${body.width} × ${body.height} см`,

        description:
          body.description?.trim() || "",

        category: "Живопись",

        status:
          body.status || "available",
      },
    });

    return NextResponse.json(artwork);
  } catch (error) {
    console.error(
      "PATCH /api/artworks/[id]:",
      error
    );

    return NextResponse.json(
      {
        error: "Ошибка обновления картины",
      },
      {
        status: 500,
      }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: Context
) {
  try {
    const { id } = await params;

    const numericId = Number(id);

    if (!Number.isInteger(numericId)) {
      return NextResponse.json(
        {
          error: "Некорректный ID картины",
        },
        {
          status: 400,
        }
      );
    }

    await prisma.artwork.delete({
      where: {
        id: numericId,
      },
    });

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    console.error(
      "DELETE /api/artworks/[id]:",
      error
    );

    return NextResponse.json(
      {
        error: "Ошибка удаления картины",
      },
      {
        status: 500,
      }
    );
  }
}